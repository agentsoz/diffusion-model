hawkesbury.xml: The main configuration file that is used to generate the diffusion model.
homeLocations: a file that includes a table that includes a row consisting of agent id, x,y coordinates (separated by tab).

